## 2.16.14 | 2026-10-30
- Simplifica ações do cabeçalho e recolhe detalhes dos relatórios por padrão.

## 2.16.13 | 2026-10-30
- Navegacao com tres abas; titulos redundantes removidos; espacamento da aba Sobre ajustado.

## 2.16.12 | 2026-10-30
- Corrige o arredondamento da aba selecionada na Admin UI.

## 2.16.11 | 2026-10-30
- Abas sem contorno e editor sem cartao externo.

## 2.16.10 | 2026-10-30
- Remove o cabecalho redundante do editor e atualiza a versao exibida.

## 2.16.6 | 2026-10-30
- Conversão visual da Admin UI com referência direta ao código do PWL Encomendas v1.5.7 e PWL Design System v1.3.1.

## 2.16.5 | 2026-10-30
- Ajustes visuais na navegacao, cabecalho e cards da Admin UI.


2.16.4 | 2026-10-29 | Ajuste da entrelinha da descrição da enquete.
## 2.16.3 | 2026-10-29
- Correção de layout em duas colunas para enquete React.

2.16.2 | 2026-10-29 | Conversao visual do frontend para layout Stitch com tokens PWL.
# Log

- 2.16.0 | 2026-10-27 | Editor experimental compilado, dez componentes shadcn/ui, integração DS, fallback PHP e validação local. Status: Em Testes. Implantação não realizada.

## 2.16.1 | 2026-10-29
- Ajuste do fluxo frontend de votacao e confirmacao, sem alterar endpoint de registro.
